"""Managed browser integration."""
