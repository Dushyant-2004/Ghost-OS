"""Safe task execution engine."""
