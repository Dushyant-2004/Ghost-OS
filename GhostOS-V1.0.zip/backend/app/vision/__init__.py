"""Vision and screenshot observation."""
