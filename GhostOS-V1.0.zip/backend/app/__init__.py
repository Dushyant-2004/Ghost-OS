"""GhostOS backend package."""
