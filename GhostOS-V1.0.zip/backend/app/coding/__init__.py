"""Restricted coding workspace services."""
